using Node.Graph.Events;
using Node.Graph.Port;
using Node.Graph.Snapshot;
using Node.Nodes.Func;

namespace Node.Graph;

public sealed class NodeGraph
{
    private readonly Dictionary<Guid, NodeLogic> _nodes = new();
    public readonly List<NodeConnection> Connections = [];
    public readonly Lock GraphLock = new();
    public readonly Dictionary<string, string> UnresolvedBrushTypeNames = new();

    public readonly List<ConnectionSnapshot> UnresolvedConnections = [];
    public readonly Dictionary<string, string> UnresolvedEffectTypeNames = new();

    public readonly List<NodeSnapshot> UnresolvedNodes = [];
    public readonly Dictionary<Guid, NodeVisualState> VisualStates = new();

    public PreviewNotifier PreviewNotifier { get; } = new();

    public IReadOnlyDictionary<Guid, NodeLogic> Nodes => _nodes;

    /// <summary>
    ///     現在BeginEditとEndEditの間の未確定編集操作の途中かどうか。
    /// </summary>
    public bool IsInTransaction { get; private set; }

    internal Action? SynchronizeBeforeEdit { get; set; }

    public void UpdateGraph(NodeGraph graph)
    {
        // 旧ノードのD2Dリソースを解放してから差し替える。
        // graph.Nodes は新しいインスタンス群なので Dispose しない。
        foreach (var node in _nodes.Values)
            node.Dispose();

        _nodes.Clear();
        foreach (var node in graph.Nodes) _nodes.Add(node.Key, node.Value);

        Connections.Clear();
        foreach (var connection in graph.Connections) Connections.Add(connection);

        VisualStates.Clear();
        foreach (var graphVisualState in graph.VisualStates)
            VisualStates.Add(graphVisualState.Key, graphVisualState.Value);

        UnresolvedNodes.Clear();
        UnresolvedNodes.AddRange(graph.UnresolvedNodes);

        UnresolvedConnections.Clear();
        UnresolvedConnections.AddRange(graph.UnresolvedConnections);

        UnresolvedEffectTypeNames.Clear();
        foreach (var kv in graph.UnresolvedEffectTypeNames)
            UnresolvedEffectTypeNames[kv.Key] = kv.Value;

        UnresolvedBrushTypeNames.Clear();
        foreach (var kv in graph.UnresolvedBrushTypeNames)
            UnresolvedBrushTypeNames[kv.Key] = kv.Value;
    }

    /// <summary>
    ///     作成済みのノードを管理下に配置します
    /// </summary>
    /// <param name="node">管理対象に追加するノードの演算実体</param>
    public void AddNode(NodeLogic node)
    {
        node.SyncDynamicInputs();

        _nodes[node.Id] = node;

        OnGraphChanged(new NodeAddedEventArgs(node.Id, node));
    }

    /// <summary>
    ///     指定したIDの管理対象のノードを削除します
    /// </summary>
    /// <param name="nodeId">削除するノードのID</param>
    public void RemoveNode(Guid nodeId)
    {
        if (!_nodes.TryGetValue(nodeId, out var node)) return;
        var related = Connections
            .Where(c => c.FromId == nodeId || c.ToId == nodeId)
            .ToList();

        foreach (var c in related)
            Disconnect(c.FromId, c.FromPort, c.ToId, c.ToPort);
        node.Invalidate();
        _nodes.Remove(nodeId);
        // グラフから永久に取り除くのでD2Dリソースを解放する。
        node.Dispose();

        OnGraphChanged(new NodeRemovedEventArgs(nodeId));
    }

    /// <summary>
    ///     指定したIDの管理対象のノードを取得します
    /// </summary>
    /// <param name="nodeId">取得するノードのID</param>
    /// <returns>得られたノードの演算実体</returns>
    public NodeLogic? GetNode(Guid nodeId)
    {
        return _nodes.GetValueOrDefault(nodeId);
    }

    /// <summary>
    ///     指定したIDの管理対象のノードの配置座標データを更新します
    /// </summary>
    /// <param name="nodeId">配置座標データを変更するノードのID</param>
    /// <param name="x">X座標</param>
    /// <param name="y">Y座標</param>
    public void SetVisualState(Guid nodeId, double x, double y)
    {
        var visual = new NodeVisualState { Id = nodeId, X = x, Y = y };
        VisualStates[nodeId] = visual;

        OnGraphChanged(new VisualStateChangedEventArgs(nodeId, visual));

        if (!IsInTransaction)
            Commit();
    }

    /// <summary>
    ///     指定したIDの管理対象のノードの配置座標データを取得します
    /// </summary>
    /// <param name="nodeId">対象のノードのID</param>
    /// <returns>指定したノードの配置座標データ</returns>
    public NodeVisualState? GetVisualState(Guid nodeId)
    {
        VisualStates.TryGetValue(nodeId, out var visualState);
        return visualState;
    }

    /// <summary>
    ///     指定したIDの管理対象のノードの出力プロパティ名を指定して、その値を取得します
    /// </summary>
    /// <param name="nodeId">出力を取得するノードのID</param>
    /// <param name="outputName">値を取得する出力プロパティ名</param>
    /// <returns>値の非同期結果</returns>
    public async Task<object?> GetOutputValue(Guid nodeId, string outputName)
    {
        if (!_nodes.TryGetValue(nodeId, out var node)) return null;
        return await node.Outputs[outputName].GetValue();
    }

    /// <summary>
    ///     指定したIDの管理対象のノードの入力プロパティ名を指定して、その値を更新します。
    /// </summary>
    /// <param name="nodeId">入力を更新するノードのID</param>
    /// <param name="inputName">値が更新される入力プロパティ名</param>
    /// <param name="value">更新する新しい値</param>
    public void SetInputValue(Guid nodeId, string inputName, object? value)
    {
        if (!_nodes.TryGetValue(nodeId, out var node)) return;
        if (!node.Inputs.TryGetValue(inputName, out var input)) return;

        input.SetValue(value);
        node.OnInputValueChanged(inputName, value);

        PreviewNotifier.Notify();
        OnGraphChanged(new ValueChangedEventArgs(nodeId, inputName, value));
    }

    /// <summary>
    ///     NodeGraph の外側で、指定ノードの値が直接書き換わったことを通知します
    /// </summary>
    public void NotifyPreviewUpdate(Guid nodeId)
    {
        if (_nodes.TryGetValue(nodeId, out var node))
            node.Invalidate();

        PreviewNotifier.Notify();
        OnGraphChanged(new GraphChangedEventArgs());
    }

    /// <summary>
    ///     指定したIDの管理対象のノードの子グラフプロパティ名を指定して、そのグラフを更新します
    /// </summary>
    /// <param name="nodeId">子グラフを更新するノードのID</param>
    /// <param name="subGraphName">グラフが更新される入力プロパティ名</param>
    /// <param name="subGraph">更新する新しいグラフ</param>
    public void SetSubgraph(Guid nodeId, string subGraphName, NodeGraph subGraph)
    {
        if (!_nodes.TryGetValue(nodeId, out var node)) return;

        var prop = node.GetType().GetProperty(subGraphName);
        if (prop != null && prop.PropertyType == typeof(NodeGraph)) prop.SetValue(node, subGraph);

        node.SubGraphs[subGraphName] = subGraph;

        OnGraphChanged(new ValueChangedEventArgs(nodeId, subGraphName, subGraph));
    }

    /// <summary>
    ///     引数ノードのポート定義を丸ごと差し替えます（引数ポートの追加・削除・型/名前の変更・並べ替え）。
    ///     ポートは作り直されるため、いったん引数ノードからの接続をすべて外し、
    ///     同じ名前のポートが残っていて型が互換な接続だけを張り直します。
    ///     文字列結合ノードが対象の場合は、文字列端子の定義を差し替えます（ReplaceTextPorts）。
    /// </summary>
    /// <param name="nodeId">自由追加に対応した引数ノードのID</param>
    /// <param name="portDefinitions">新しいポート定義（並び順がそのまま表示順になる）</param>
    /// <returns>
    ///     差し替えた場合はtrue。対象が自由追加に対応した引数ノードでない場合、元からある固定ポートが
    ///     変更・削除されている場合、ポート名が重複している場合、追加ポートの型が未対応の場合、
    ///     追加によって引数ポート数が上限（ArgumentPortKinds.MaxCustomPorts）を超える場合は何もせずfalse。
    /// </returns>
    public bool ReplaceArgumentPorts(Guid nodeId, PortDefinition[] portDefinitions)
    {
        if (!_nodes.TryGetValue(nodeId, out var target))
            return false;

        if (target is ArgumentsNode { AllowCustomPorts: true } argumentsNode)
        {
            if (portDefinitions.Select(d => d.Name).Distinct().Count() != portDefinitions.Length)
                return false;

            if (argumentsNode.GetPortDefinitions().Any(d => !d.IsCustom && !portDefinitions.Contains(d)))
                return false;

            if (portDefinitions.Any(d => d.IsCustom && !ArgumentPortKinds.TryGetKind(d.ValueType, out _)))
                return false;

            // 引数ポート数の上限を超える追加は拒否する。上限を超えて保存済みのグラフでも、
            // 数を増やさない編集（名前変更・削除・並べ替え）は許可する。
            var customCount = portDefinitions.Count(d => d.IsCustom);
            if (customCount > ArgumentPortKinds.MaxCustomPorts &&
                customCount > argumentsNode.GetPortDefinitions().Count(d => d.IsCustom))
                return false;

            ApplyArgumentPorts(argumentsNode, portDefinitions);
            return true;
        }

        if (target is IPortDefinitionNode dynamicNode)
            return ReplaceDynamicPorts(dynamicNode, portDefinitions);

        return false;
    }

    private void ApplyArgumentPorts(ArgumentsNode argumentsNode, PortDefinition[] portDefinitions)
    {
        var nodeId = argumentsNode.Id;
        var outgoing = Connections.Where(c => c.FromId == nodeId).ToList();
        foreach (var c in outgoing)
            DisconnectSilently(c.FromId, c.FromPort, c.ToId, c.ToPort);

        argumentsNode.Initialize(portDefinitions);

        foreach (var c in outgoing)
            if (argumentsNode.Outputs.ContainsKey(c.FromPort))
                Connect(c.FromId, c.FromPort, c.ToId, c.ToPort);

        argumentsNode.Invalidate();
        OnGraphChanged(new ConnectionChangedEventArgs(null, null, nodeId, null));
    }

    private void ApplyReturnPorts(ReturnNode returnNode, PortDefinition[] portDefinitions)
    {
        var nodeId = returnNode.Id;
        var incoming = Connections.Where(c => c.ToId == nodeId).ToList();
        foreach (var c in incoming)
            DisconnectSilently(c.FromId, c.FromPort, c.ToId, c.ToPort);

        returnNode.Initialize(portDefinitions);

        foreach (var c in incoming)
            if (returnNode.Inputs.ContainsKey(c.ToPort))
                Connect(c.FromId, c.FromPort, c.ToId, c.ToPort);

        returnNode.Invalidate();
        OnGraphChanged(new ConnectionChangedEventArgs(null, null, nodeId, null));
    }

    private bool ReplaceDynamicPorts(IPortDefinitionNode node, PortDefinition[] portDefinitions)
    {
        if (!node.IsValidPortSet(portDefinitions))
            return false;

        var nodeLogic = (NodeLogic)node;
        var remainingNames = portDefinitions.Select(d => d.Name).ToHashSet();

        var connections = node.DynamicPortsAreOutputs
            ? Connections.Where(c => c.FromId == nodeLogic.Id &&
                                     node.GetPortDefinitions().Any(d => d.Name == c.FromPort))
                .ToList()
            : Connections.Where(c => c.ToId == nodeLogic.Id &&
                                     node.GetPortDefinitions().Any(d => d.Name == c.ToPort))
                .ToList();

        var oldValues = node.DynamicPortsAreOutputs
            ? new Dictionary<string, object?>()
            : node.GetPortDefinitions()
                .Where(d => nodeLogic.Inputs.ContainsKey(d.Name))
                .ToDictionary(d => d.Name, d => nodeLogic.Inputs[d.Name].LocalValue);

        foreach (var connection in connections)
            DisconnectSilently(connection.FromId, connection.FromPort, connection.ToId, connection.ToPort);

        node.Initialize(portDefinitions);

        if (!node.DynamicPortsAreOutputs)
        {
            foreach (var definition in portDefinitions)
            {
                if (oldValues.TryGetValue(definition.Name, out var value) && value != null &&
                    nodeLogic.Inputs.TryGetValue(definition.Name, out var input))
                    input.SetValue(value);
            }
        }

        foreach (var connection in connections)
        {
            var portName = node.DynamicPortsAreOutputs ? connection.FromPort : connection.ToPort;
            if (remainingNames.Contains(portName))
                Connect(connection.FromId, connection.FromPort, connection.ToId, connection.ToPort);
        }

        node.NotifyPortDefinitionsChanged();
        nodeLogic.Invalidate();
        OnGraphChanged(new ConnectionChangedEventArgs(null, null, nodeLogic.Id, null));
        return true;
    }

    /// <summary>
    ///     このグラフが管理しているすべてのノードを再計算待ち状態にします
    /// </summary>
    public void InvalidateAll()
    {
        foreach (var node in _nodes.Values) node.Invalidate();
    }

    /// <summary>
    ///     このグラフが管理しているノード２つのそれぞれ指定した入出力プロパティ名同士にデータの依存関係を構築します
    /// </summary>
    /// <param name="from">接続が追加される出力プロパティを持つノードのID</param>
    /// <param name="outputName">接続が追加される出力プロパティ名</param>
    /// <param name="to">接続が設定される入力プロパティを持つノードのID</param>
    /// <param name="inputName">接続が設定される入力プロパティ名</param>
    /// <returns>接続を追加した場合はtrue。循環接続または型が非互換のため拒否した場合はfalse。</returns>
    public bool Connect(
        Guid from, string outputName,
        Guid to, string inputName)
    {
        if (GetConnectionRejection(from, outputName, to, inputName) != ConnectionRejection.None)
            return false;

        if (!TryGetPorts(from, outputName, to, inputName, out var output, out var input))
            return false;

        var existing = Connections
            .Where(c => c.ToId == to && c.ToPort == inputName)
            .ToList();

        foreach (var c in existing)
            Disconnect(c.FromId, c.FromPort, c.ToId, c.ToPort);

        input.Connect(output);
        Connections.Add(
            new NodeConnection { FromId = from, FromPort = outputName, ToId = to, ToPort = inputName });

        OnGraphChanged(new ConnectionChangedEventArgs(from, outputName, to, inputName));
        return true;
    }

    /// <summary>
    ///     指定した出力ポートから入力ポートへの接続が拒否されるかどうかを判定し、拒否される場合はその理由を返す。
    ///     Connect が接続を拒否する条件はこのメソッドが唯一の基準であり、エディタ上での事前表示も同じ判定を共有する。
    /// </summary>
    /// <param name="from">接続元の出力ポートを持つノードのID</param>
    /// <param name="outputName">接続元の出力ポート名</param>
    /// <param name="to">接続先の入力ポートを持つノードのID</param>
    /// <param name="inputName">接続先の入力ポート名</param>
    /// <returns>接続できる場合は None。拒否される場合はその理由。</returns>
    public ConnectionRejection GetConnectionRejection(
        Guid from, string outputName,
        Guid to, string inputName)
    {
        if (WouldCreateCycle(from, to))
            return ConnectionRejection.Cycle;

        if (!TryGetPorts(from, outputName, to, inputName, out var output, out var input))
            return ConnectionRejection.PortNotFound;

        if (!ArePortTypesCompatible(output.ValueType, input.ValueType))
            return ConnectionRejection.IncompatibleTypes;

        return ConnectionRejection.None;
    }

    /// <summary>
    ///     出力ポートの型を入力ポートへ接続してよいかどうかを判定する。
    /// </summary>
    /// <param name="outputType">接続元の出力ポートの値の型</param>
    /// <param name="inputType">接続先の入力ポートの値の型</param>
    /// <returns>接続を許可できる場合はtrue</returns>
    private static bool ArePortTypesCompatible(Type outputType, Type inputType)
    {
        return PortTypeCompatibility.Evaluate(outputType, inputType) != PortCompatibility.Incompatible;
    }

    /// <summary>
    ///     指定したノード間に新たに接続（from → to）を追加した場合に、
    ///     グラフが循環（あるノードが自分自身に依存する状態）になるかどうかを判定する。
    ///     既存の接続を to から辿って from に到達できるなら、新しい接続によって循環が生じる。
    /// </summary>
    /// <param name="from">接続の出力側ノードのID</param>
    /// <param name="to">接続の入力側ノードのID</param>
    /// <returns>循環接続になる場合はtrue</returns>
    public bool WouldCreateCycle(Guid from, Guid to)
    {
        if (from == to) return true;

        var visited = new HashSet<Guid>();
        var stack = new Stack<Guid>();
        stack.Push(to);

        while (stack.Count > 0)
        {
            var current = stack.Pop();
            if (current == from) return true;
            if (!visited.Add(current)) continue;

            foreach (var connection in Connections)
                if (connection.FromId == current)
                    stack.Push(connection.ToId);
        }

        return false;
    }

    /// <summary>
    ///     このグラフが管理しているノード２つのそれぞれ指定した入出力プロパティ名同士のデータの依存関係を削除します
    /// </summary>
    /// <param name="from">接続が削除される出力プロパティを持つノードのID</param>
    /// <param name="outputName">接続が削除される出力プロパティ名</param>
    /// <param name="to">接続が削除される入力プロパティを持つノードのID</param>
    /// <param name="inputName">接続が削除される入力プロパティ名</param>
    public void Disconnect(
        Guid from, string outputName,
        Guid to, string inputName)
    {
        if (TryGetPorts(from, outputName, to, inputName, out var output, out var input))
            input.DisConnect(output);

        Connections.RemoveAll(c =>
            c.FromId == from &&
            c.FromPort == outputName &&
            c.ToId == to &&
            c.ToPort == inputName);

        OnGraphChanged(new ConnectionChangedEventArgs(from, outputName, null, null));
        OnGraphChanged(new ConnectionChangedEventArgs(null, null, to, inputName));
    }

    internal void DisconnectSilently(
        Guid from, string outputName,
        Guid to, string inputName)
    {
        if (TryGetPorts(from, outputName, to, inputName, out var output, out var input))
            input.DisConnect(output);

        Connections.RemoveAll(c =>
            c.FromId == from &&
            c.FromPort == outputName &&
            c.ToId == to &&
            c.ToPort == inputName);
    }

    private bool TryGetPorts(
        Guid from, string outputName, Guid to, string inputName,
        out OutputPort output, out InputPort input)
    {
        output = null!;
        input = null!;

        if (!_nodes.TryGetValue(from, out var fromNode) || !fromNode.Outputs.TryGetValue(outputName, out var o))
            return false;
        if (!_nodes.TryGetValue(to, out var toNode) || !toNode.Inputs.TryGetValue(inputName, out var i))
            return false;

        output = o;
        input = i;
        return true;
    }

    /// <summary>
    ///     このグラフが変更され、ノードの入出力の値が更新された可能性があることを通知します
    /// </summary>
    public event EventHandler<GraphChangedEventArgs>? GraphChanged;

    /// <summary>
    ///     このグラフに対し行われた変更操作が内部から確定されたことを通知します
    /// </summary>
    public event EventHandler<CommittedEventArgs>? Committed;

    public void OnGraphChanged(GraphChangedEventArgs args)
    {
        args.IsInTransaction = IsInTransaction;
        GraphChanged?.Invoke(this, args);
    }

    public void Commit()
    {
        Committed?.Invoke(this, new CommittedEventArgs());
    }

    /// <summary>
    ///     このグラフに対して何らかの編集操作が開始することを通達します
    /// </summary>
    public void BeginEdit()
    {
        SynchronizeBeforeEdit?.Invoke();
        IsInTransaction = true;
    }

    /// <summary>
    ///     このグラフに対して行われた編集操作を完了し、確定します。
    ///     値の「確定」に相当し、PreviewNotifier 経由のプレビュー更新に加えて、
    ///     Commit（Undo履歴の記録）と全ノードの再計算を行う。
    /// </summary>
    public void EndEdit()
    {
        if (!IsInTransaction) return;
        IsInTransaction = false;

        PreviewNotifier.Notify();
        OnGraphChanged(new GraphChangedEventArgs());

        Commit();
        InvalidateAll();
    }
}