using System.Windows.Media;
using Node.Graph;

namespace Node.Nodes.MathCalc;

public sealed class MathBasicCategory : INodeCategory
{
    public string Category => "NodeEffectKey_MathCategoryName/NodeEffectKey_BasicCategoryName";
    public string Color => nameof(Colors.DarkOrange);
}

public sealed class MathFunctionsCategory : INodeCategory
{
    public string Category => "NodeEffectKey_MathCategoryName/NodeEffectKey_FunctionsCategoryName";
    public string Color => nameof(Colors.DarkOrange);
}

public sealed class MathAdvancedCategory : INodeCategory
{
    public string Category => "NodeEffectKey_MathCategoryName/NodeEffectKey_AdvancedCategoryName";
    public string Color => nameof(Colors.DarkOrange);
}